const products=[
{id:1,cat:'minecraft',name:'VIP Rank Minecraft',desc:'Cargo VIP para seu servidor.',price:19.90,icon:'⛏️'},
{id:2,cat:'minecraft',name:'1000 Coins',desc:'Moeda virtual para experiências.',price:14.90,icon:'💎'},
{id:3,cat:'minecraft',name:'Pack Premium',desc:'Conteúdo digital especial.',price:29.90,icon:'🟪'},
{id:4,cat:'roblox',name:'Robux Pack',desc:'Créditos digitais para Roblox.',price:24.90,icon:'🟥'},
{id:5,cat:'roblox',name:'VIP Roblox',desc:'Benefícios exclusivos.',price:34.90,icon:'👑'},
{id:6,cat:'roblox',name:'Skin Bundle',desc:'Pacote visual digital.',price:12.90,icon:'🎭'},
{id:7,cat:'minecraft',name:'Kit Builder',desc:'Itens para construção.',price:9.90,icon:'🧱'},
{id:8,cat:'roblox',name:'Game Pass',desc:'Passe digital demonstrativo.',price:39.90,icon:'🎮'}];
let cart=[];
const money=n=>n.toLocaleString('pt-BR',{style:'currency',currency:'BRL'});
function render(filter='all'){const el=document.getElementById('products');el.innerHTML=products.filter(p=>filter==='all'||p.cat===filter).map(p=>`<article class="product"><div class="cover">${p.icon}</div><h3>${p.name}</h3><p>${p.desc}</p><div class="price"><strong>${money(p.price)}</strong><button class="add" onclick="add(${p.id})">Adicionar</button></div></article>`).join('')}
function filterProducts(f,b){document.querySelectorAll('.filters button').forEach(x=>x.classList.remove('active'));b.classList.add('active');render(f)}
function add(id){cart.push(products.find(p=>p.id===id));updateCart();showToast('Produto adicionado ao carrinho')}
function updateCart(){document.getElementById('cartCount').textContent=cart.length;document.getElementById('cartItems').innerHTML=cart.length?cart.map((p,i)=>`<div class="cart-row"><div style="font-size:25px">${p.icon}</div><div style="flex:1"><b>${p.name}</b><br><small>${money(p.price)}</small></div><button class="add" onclick="removeItem(${i})">×</button></div>`).join(''):'<p style="color:#777">Seu carrinho está vazio.</p>';document.getElementById('cartTotal').textContent=money(cart.reduce((s,p)=>s+p.price,0))}
function removeItem(i){cart.splice(i,1);updateCart()}
function openCart(){document.getElementById('cartPanel').classList.add('open')}
function closeCart(){document.getElementById('cartPanel').classList.remove('open')}
function checkout(){if(!cart.length)return showToast('Adicione um produto primeiro');showToast('Checkout demonstrativo — conecte seu gateway de pagamento.')}
function showToast(t){const e=document.getElementById('toast');e.textContent=t;e.classList.add('show');setTimeout(()=>e.classList.remove('show'),2200)}
setInterval(()=>{const e=document.getElementById('online');e.textContent=(1200+Math.floor(Math.random()*130)).toLocaleString('pt-BR')},5000);
render();
