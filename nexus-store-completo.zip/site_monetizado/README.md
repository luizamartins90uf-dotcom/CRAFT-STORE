# NEXUS STORE — projeto inicial

## O que já vem pronto
- Loja responsiva com visual dark premium
- Catálogo Minecraft/Roblox
- Filtros de categoria
- Carrinho funcional no navegador
- Página de administração demonstrativa
- Estrutura pronta para monetização

## Monetização real
O site **não gera dinheiro automaticamente**. Para monetizar de forma legítima, conecte:
1. Uma plataforma de anúncios (ex.: Google AdSense) depois de o site estar publicado e aprovado.
2. Um gateway de pagamento para vendas.
3. Analytics para medir visitantes e conversões.
4. Links de afiliado, quando aplicável.

Não use recarregamentos, bots ou permanência artificial para gerar impressões de anúncios.

## Publicação
O projeto é estático e pode ser publicado em serviços de hospedagem estática. Abra `index.html` localmente para testar.

## Próximos passos
- Substituir produtos demonstrativos pelos seus produtos reais.
- Configurar domínio.
- Integrar checkout/pagamento.
- Integrar banco de dados e login se necessário.
- Inserir o código de anúncios somente após aprovação da rede escolhida.
